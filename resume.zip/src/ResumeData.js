import homeImage from "./assets/vani.jpg";
// ========================== Header Data
const headerIds = [
  "home",
  "profile",
  "education",
  "skills",
  "experience",
  "certificates",
];
const HeaderLinks = [
  {
    linkText: "Home",
    linkID: "home",
    boxIcon: "bx-home",
  },
  {
    linkText: "Profile",
    linkID: "profile",
    boxIcon: "bx-user",
  },
  {
    linkText: "Education",
    linkID: "education",
    boxIcon: "bx-book",
  },
  {
    linkText: "Skills",
    linkID: "skills",
    boxIcon: "bx-receipt",
  },
  {
    linkText: "Experience",
    linkID: "experience",
    boxIcon: "bx-briefcase-alt",
  },
  {
    linkText: "Certificates",
    linkID: "certificates",
    boxIcon: "bx-award",
  },
  //   {
  //     linkText: "References",
  //     linkID: "references",
  //     boxIcon: "bx-link-external",
  //   },
];

//  ===================================== Left Section Content =============================== //
// ========================== Home Data
const homeData = {
  homeImage,
  homeTitle1: "Gogilavani",
  homeTitle2: "Vasanthakumar",
  homeProfession: "Web Developer",
  homeInformation: [
    {
      text: " Erode, Tamilnadu, India",
      icon: "bx-map",
    },
    {
      text: "gogila.vasanth@gmail.com",
      icon: "bx-envelope",
    },
    {
      text: " +91 9894010943",
      icon: "bx-phone",
    },
  ],
};

// ========================== Social Links
const socialLinks = {
  title: "Social",
  links: [
    {
      link: "https://github.com/vanivasanth",
      text: "VaniVasanth",
      icon: "bxl-github",
    },
    {
      link: "https://www.facebook.com/gogilavani.vasanthakumar",
      text: "VaniVasanth",
      icon: "bxl-facebook",
    },
    {
      link: "https://www.linkedin.com/in/gogilavani-vasanthakumar-8ab749195/",
      text: "VaniVasanth",
      icon: "bxl-linkedin-square",
    },
  ],
};

// ========================== Profile Data
const profileData = {
  title: "About me",
  //   Here you can add as much paragraph as you can
  descriptions: [
    `I am a person interested in learning new technologies and looking for career development`,
    
  ],
};

// ========================= Education Data
const educationData = {
  title: "Education",
  educations: [
    {
      title: "Master of Computer Application",
      studies: "Erode Sengunthar Engineering College, Tamilnadu, India",
      year: "2009 - 2012",
      line: true,
    },
    {
      title: "Bachelor of Computer Application",
      studies: "Maharaja College for Women, Perundurai, Tamilnadu, India",
      year: "2006 - 2009",
      line: false,
    },
  ],
};

// ========================= Skills Data
const skillsData = {
  title: "Skills",
  //   Here you can add further skills array
  skills: [
    [`HTML`, `CSS`, `Javascript`],
    [`Angular 8`, `React 17.0`],
  ],
};
const logoText = "Vanivasanth";
const menuIcon = "bx-grid-alt";

//  ===================================== Right Section Content =============================== //

// ======================== Certificates Data
const certificatesData = {
  title: "Certificates",
  certificates: [
    {
      title: "Angular 8.0",
      describe:
        "Learned angular framework and worked on simple projects to familiarise the concepts",
    },
  ],
};

// ========================= Experience Data
const experienceData = {
  title: "Experience",
  experiences: [
    {
      title: "Associate Software Engineer/Web UI Developer,",
      company:"Cognitive Mobile Technologies, Chennai",
      duration:"(May 2021 - PRESENT)",
      describe:"Working as a Front-end developer. Primary responsibilities are to develop Front-end of Web pages using angular and react js.",
      line: true,
    },
    {
      title: "Hands-on",
      company: "SoftLogic Academy, Chennai",
      duration:"Dec 2020 - Apr 2021",
      describe: "Joined in an institute to learn front-end development. Worked in small modules like Router-navigation in angular, simple web models, etc.",
      line: false,
    },
  ],
};

// ========================= Languages Data
const languageData = {
  title: "Languages",
  languages: ["English", "Tamil"],
};

// ========================= INTERESTS Data
const interestsData = {
  title: "INTERESTS",
  interests: [
    {
      icon: "bxs-plane-alt",
      text: "Travel",
    },
    {
      icon: "bx-headphone",
      text: "Music",
    },
    {
      icon: "bx-book",
      text: "Reading",
    },
  ],
};
export {
  HeaderLinks,
  logoText,
  menuIcon,
  homeData,
  socialLinks,
  profileData,
  educationData,
  skillsData,
  certificatesData,
  experienceData,
  languageData,
  interestsData,
  headerIds
};