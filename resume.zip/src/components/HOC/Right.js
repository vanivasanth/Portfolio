import React from 'react'

const Right = ({children}) => {
    return (
      
            <div className="resume__right">
                {children}
            </div>
     

    )
}

export default Right