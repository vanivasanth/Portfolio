import React from 'react'

const Left = ({children}) => {
    return (
      
            <div className="resume__left">
                {children}
            </div>
     

    )
}

export default Left;